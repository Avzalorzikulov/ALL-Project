let chairs = [
    {
      id: 1,
      name: " LD01 LOUNGE CHAIR",
      price: 200,
      image: "img/1.png",
      description:
        "Expertly rendered by Carl Hansen & Søn, the lounge chair—first introduced in 1951 and enduring ever since—is available in oak or as a combination of oak and walnut, sourced from sustainable forestry. Choose from seat and back upholstery in a selection of leather options or in a custom fabric.",
    },
    {
      id: 2,
      name: " LD02 LOUNGE CHAIR",
      price: 250,
      image: "img/2.png",
      description:
        "Expertly rendered by Carl Hansen & Søn, the lounge chair—first introduced in 1951 and enduring ever since—is available in oak or as a combination of oak and walnut, sourced from sustainable forestry. Choose from seat and back upholstery in a selection of leather options or in a custom fabric.",
    },
    {
      id: 3,
      name: " LD03 LOUNGE CHAIR",
      price: 290,
      image: "img/3.png",
      description:
        "Expertly rendered by Carl Hansen & Søn, the lounge chair—first introduced in 1951 and enduring ever since—is available in oak or as a combination of oak and walnut, sourced from sustainable forestry. Choose from seat and back upholstery in a selection of leather options or in a custom fabric.",
    },
    {
      id: 4,
      name: " LD04 LOUNGE CHAIR",
      price: 200,
      image: "img/4.png",
      description:
        "Expertly rendered by Carl Hansen & Søn, the lounge chair—first introduced in 1951 and enduring ever since—is available in oak or as a combination of oak and walnut, sourced from sustainable forestry. Choose from seat and back upholstery in a selection of leather options or in a custom fabric.",
    },
    {
      id: 5,
      name: " LD05 LOUNGE CHAIR",
      price: 300,
      image: "img/5.png",
      description:
        "Expertly rendered by Carl Hansen & Søn, the lounge chair—first introduced in 1951 and enduring ever since—is available in oak or as a combination of oak and walnut, sourced from sustainable forestry. Choose from seat and back upholstery in a selection of leather options or in a custom fabric.",
    },
    {
      id: 6,
      name: " LD06 LOUNGE CHAIR",
      price: 200,
      image: "img/6.png",
      description:
        "Expertly rendered by Carl Hansen & Søn, the lounge chair—first introduced in 1951 and enduring ever since—is available in oak or as a combination of oak and walnut, sourced from sustainable forestry. Choose from seat and back upholstery in a selection of leather options or in a custom fabric.",
    },
    {
      id: 7,
      name: " LD07 LOUNGE CHAIR",
      price: 200,
      image: "img/7.png",
      description:
        "Expertly rendered by Carl Hansen & Søn, the lounge chair—first introduced in 1951 and enduring ever since—is available in oak or as a combination of oak and walnut, sourced from sustainable forestry. Choose from seat and back upholstery in a selection of leather options or in a custom fabric.",
    },
    {
      id: 8,
      name: " LD08 LOUNGE CHAIR",
      price: 200,
      image: "img/8.png",
      description:
        "Expertly rendered by Carl Hansen & Søn, the lounge chair—first introduced in 1951 and enduring ever since—is available in oak or as a combination of oak and walnut, sourced from sustainable forestry. Choose from seat and back upholstery in a selection of leather options or in a custom fabric.",
    },
  ];