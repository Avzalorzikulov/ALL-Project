const itemId = new URLSearchParams(window.location.search).get("id");
const elBody = document.querySelector("body");
function renderDetail() {
  const product = chairs.find((el) => el.id == itemId);
  console.log(product);
  elBody.innerHTML = `<h1  class="title">PRODUCT DETAIL</h1>
<ul class="list">
        <img src="${product.image}" alt="this is chair img" class="div-img">
    <div class="div">
        <h3 class="div-title">${product.name}</h3>
        <h5 class="price">$${product.price}</h5>
        <div class="btn-div">
            <button class="btn-1">Check Out</button>
            <button class="btn-2">Add To Cart</button>
        </div>
        <p class="div-description">${product.description}</p>
    </div>
</ul>`;
}

renderDetail();
