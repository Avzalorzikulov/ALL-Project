#  1 chi vazifa
# a = 8756;
# b = a // 1000
# c = (a // 100) % 10;
# d = (a // 10) % 10;
# e =a%10
# print(b+c+d+e)
# 2 chi vazifa
# c = 748
# a = c //100;
# v = c *10;
# v = v %1000;
# print(a+v) 
# 3 chi fazifa
# c = 74823
# a = c //1000;
# v = c *100;
# v = v %100000;
# print(a+v) 

